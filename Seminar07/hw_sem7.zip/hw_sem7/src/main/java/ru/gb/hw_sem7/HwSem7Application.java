package ru.gb.hw_sem7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HwSem7Application {

	public static void main(String[] args) {
		SpringApplication.run(HwSem7Application.class, args);
	}

}
