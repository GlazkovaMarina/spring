package ru.gb.hw_sem5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HwSem5Application {

	public static void main(String[] args) {
		SpringApplication.run(HwSem5Application.class, args);
	}

}
